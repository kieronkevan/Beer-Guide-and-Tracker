# The Beer Passport — setup

## What's here
- `docs/` — the static site (this is what GitHub Pages serves). `data.json` already
  has your real 25 beers, so the site works right now even before the Notion sync
  is wired up — open `docs/index.html` in a browser to check it.
- `scripts/sync-notion.js` — pulls current data from your 4 Notion databases and
  rewrites `docs/data.json`.
- `.github/workflows/sync-and-deploy.yml` — runs the sync automatically every day,
  or whenever you push, and commits the refreshed data.

## One-time setup

**1. Create a repo** (if you haven't already) and push these files to it, on the
`main` branch, with `docs/` as a top-level folder.

**2. Turn on GitHub Pages**
Repo → Settings → Pages → Source: "Deploy from a branch" → Branch: `main`, folder: `/docs`.

**3. Create a Notion integration**
Go to notion.so/my-integrations → "New integration" → give it a name (e.g.
"Beer Guide Sync") → copy the **Internal Integration Secret**.

**4. Share your databases with the integration**
Open each of the 4 databases (Beers, Countries, Breweries, Styles) in Notion →
"..." menu → Connections → add your new integration. All 4 need this, or the
sync will fail on whichever one is missing.

**5. Get each database's data source ID**
Easiest way: open each database in Notion, copy its URL, and take the 32-character
ID from it. (If a database ever gets more than one "view source" this can differ
from the database ID — ask me if a sync run errors on this and I'll help track
down the right ID.)

**6. Add the secrets to GitHub**
Repo → Settings → Secrets and variables → Actions → New repository secret, one for each:
- `NOTION_TOKEN` — the integration secret from step 3
- `NOTION_BEERS_DS`
- `NOTION_COUNTRIES_DS`
- `NOTION_BREWERIES_DS`
- `NOTION_STYLES_DS`

**7. Run it**
Actions tab → "Sync Notion data and deploy" → "Run workflow" to trigger it manually
the first time. After that it runs daily on its own, and also whenever you push
to `main`.

## Notes
- Photos: if you add a photo to a beer in Notion, the sync script downloads it
  into `docs/images/` during the run — Notion's own image links expire after
  about an hour, so this step is required, not optional.
- The write-up (page body text) only gets pulled for beers marked "Tried" or with
  "Would try again" ticked, to keep the sync fast — let me know if you want that
  changed to pull for every beer regardless of status.
